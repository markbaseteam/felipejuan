## Juros Compostos

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F15d76666-199f-48d8-b269-ef0d849fe030%2FUntitled.png?id=3945e3b2-1db4-4b09-abec-c2b340295032&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=860&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Essa é a fórmula do Montante, quando a questão estiver pedindo em Juros Compostos. Lembrando mais uma vez: C = Capital Investido / i = taxa / t = tempo

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fc9980bac-7d2d-41f4-8f66-da27de544772%2FUntitled.png?id=6352a49d-e262-413e-9704-4ad1ae7b0188&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Idêntico a questão de Juros Simples - exatamente, os mesmos dados, como de taxa, tempo, e capital inicial - com a única diferença, e essa grande, essa está pedindo a taxa de juros compostos.

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fef136095-9c55-4027-89f4-55a17e6d85b4%2FUntitled.png?id=140505e7-15a6-4d6f-bd81-a319bf589000&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Essas questões, podem não pedir apenas o montante como resposta final - mas sim, que através dela, conseguirá os valores para substituir e descobrir o que pede - como foi nesse primeiro exemplo, pedindo o juros, e trocando os valores na primeira fórmula de montate.

Detalhe também que foi convertido o “um ano e meio” para 18 meses, que se tornou o expoente, de acordo com a fórmula.

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fc8daa6ae-8cb7-4819-90c7-2533f431637e%2FUntitled.png?id=e08f12ac-724d-4192-9ec0-96f8243e56c7&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Aqui teve a conversão das taxas em decimal, primeiro, para poder somar com o 1 da fórmula, e posteriormente, foram convertidas em fração, para poder resolver a equação de uma maneira mais fácil.

Não tem segredo - tenha a fórmula memorizada, separe os dados do enunciado e substitua na equação.

Apenas um detalhe que, enquanto na fórmula de juros simples, o recomendável, é transfomar a taxa em fração, na fórmula do montante, o melhor é converter a taxa em decimal. Afinal, terei que somar + 1,00 nele.