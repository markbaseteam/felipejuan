## Juros Simples

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F548790c6-b556-4b69-9f8f-3ae836cb51c9%2FUntitled.png?id=4be3700b-393d-4953-a28c-ba9da983cb36&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=860&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

J = Juros / C = Capital Investido / i = taxa / t = tempo Montante: M = C + J

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F9c51effa-0076-4332-93d5-7817c30ba1ba%2FUntitled.png?id=fde5df41-4647-4151-8b8e-98e5aafadc02&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Esse conteúdo, em geral, é bem simples e estou relativamente familiarizado por conta do 9º ano. Contudo, bom lembrar destas duas coisas para ficar mais atento:

Deixar o tempo e a taxa, na mesma unidade de tempo. Converter, quando preciso. Por exemplo, pode acontecer do tempo estar em 2 anos, mas a taxa estar 5% am. Nesse caso, precisariamos converter esse tempo em meses, a qual daria 24 meses (2 \* 12). Contudo, ambos são possíves converter (taxa e tempo) - o importante é ter um deles como base:

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F8498c182-2a0c-4e5a-9f6f-8a138ea12953%2FUntitled.png?id=233c2650-2e97-48d1-b649-82a7d63a8a07&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=580&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Para facilitar a equação, é recomendável converter a porcentagem em uma fração, a qual ele fica sobre 100. Assim foi feito o exercício acima e como será nos outros.

De qualquer forma, aplicando essa fórmula, o problema acima seria resolvido assim:

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fe797ad2b-9a1a-42d1-a1bf-79c62bd8edf1%2FUntitled.png?id=48f3d729-e348-453e-afbc-08e9215d9a58&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=770&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fdaef1e02-8985-4cc8-b7bc-fb88960414bc%2FUntitled.png?id=cda0e697-558a-40ab-9dca-8b4390b001d7&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Ffc3595c5-ea54-4989-a261-27d25c69da05%2FUntitled.png?id=5947f401-2e6d-4e36-ab9a-be642f8731b8&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Como pode ser observado, os problemas desse assunto costumam mais ser de encontrar tal valor a qual se tornará uma incógnita. Pelo que lembro, os problemas que davam no fundamental eram assim também.

Imagino que a minha dificuldade seria na parte do montante - é algo bobo, mas não consigo identificar ao mesmo instante quando / para que está se referindo ao montante.

Por exemplo. nesse segundo segundo exercício, o valor duplicado da capital, já se refere ao valor no resultado final, dentro do montante.