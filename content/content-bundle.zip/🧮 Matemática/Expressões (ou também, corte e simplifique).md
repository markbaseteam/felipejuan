## Expressões (ou também, corte e simplifique)

Uma coisa que preciso aprender, é simplificar de verdade em expressões assim:
![|500](*https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F3c1a94c8-5c0b-4405-9ebb-09546d971858%2FUntitled.png?id=f4325ecd-03ab-4e8b-8716-b9e58366cbda&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1320&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)*

##### Preciso bater o olho e perceber - para simplificar, o melhor jeito é tornar tudo um só. No caso, transformar em frações o que não estão. E ver o que nem precisa. Por exemplos:

> [!NOTE] 
Ver se é uma fração que dá para resolver, como o $\frac{12}{4}$, que é igual 3 (e deixar esse número no lugar)
![|180](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F09a1667a-011b-48b0-87a1-a36f33203630%2F2023_05_28_16_37_Office_Lens.jpg?id=e2791500-4543-416c-8201-a1a1741ee469&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=380&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

> [!summary] Title
> Contents
Se tiver número em decimal, então transforme em fração. Após isso, **simplifique o máximo possível.**
![|230](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fab3748b5-1415-4cb8-801a-572343af336d%2F2023_05_28_16_38_Office_Lens.jpg?id=e79c2c3c-277e-4896-95ad-70dc80cbbd99&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=480&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

> [!important]  Title
> Contents
Em uma multiplicação, se tiver um número em cima em um, e mesmo número, mas embaixo do outro, você pode apenas cortar o número... **TU PRECISA SEMPRE CORTAR QUANDO POSSÍVEL:**
![|300](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F47730dad-b262-4630-b7c8-5490f97829dc%2F2023_05_28_17_02_Office_Lens.jpg?id=421b40af-0b3e-4bcb-91c0-42aaa74333d2&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=670&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
![|300](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fb5bd5083-78a6-48bd-8b40-e2a84a50ca62%2F2023_05_29_15_19_Office_Lens.jpg?id=36714074-6c00-400e-a5c3-875e98b9e8d6&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=860&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

