# 📄 Modelos de Redação

### [Modelo 1](https://www.youtube.com/watch?v=cgVHKowutkE&t=194s)
O filósofo brasileiro Raimundo Teixeira Mendes, em 1889, adaptou o lema positivista “Ordem e Progresso” não só para a Bandeira Nacional, mas também para a nação que, no contexto hodierno, enfrenta significativos estorvos para o seu desenvolvimento. Lamentavelmente, entre eles, o (TEMA) representa uma antítese à máxima do símbolo pátrio, uma vez que tal postura resulta na desordem e no retrocesso do desenvolvimento social. Esse lastimável panorama é calcado na inoperância estatal e tem como consequência o (ARG. 2).

De início, há de se constatar a débil ação do Poder Público enquanto mantenedora da problemática. Acerca disso, o filósofo inglês Thomas Hobbes, em seu livro "Leviatã", defende a incumbência do Estado em proporcionar meios que auxiliem o progresso da coletividade. As autoridades, contudo, vão de encontro com a ideia de Hobbes, uma vez que possuem um papel inerte em relação ao PROBLEMA. Esse cenário decorre do fato de que, assim como pontuou o economista norte-americano Murray Rothbard, uma parcela dos representantes governamentais, ao se orientar por um viés individualista e visar a um retorno imediato de capital político, negligencia a conservação de direitos sociais indispensáveis, como o DIREITO NEGLIGENCIADO. Logo, é notório que a omissão do Estado perpetua o PROBLEMA no Brasil.

Por conseguinte, engendra-se a (ARG. 2 (consequência)). Posto isso, de acordo com (Repertório: dados estatísticos/percentuais). Diante de tal exposto, (APROFUNDAMENTO ARGUMENTATIVO). Portanto, é inadmissível que esse cenário continue a perdurar.

Diante do exposto, é mister a atuação governamental no PROBLEMA. Assim, a fim de (FINALIDADE), cabe ao Poder Executivo Federal, mais especificamente ao Ministério X, (AÇÃO), (FINALIDADE). Tal ação deverá ocorrer por meio da (MEIO/MODO). Somente assim, com a conjuntura de tais ações, os brasileiros verão o progresso referido na Bandeira Nacional Brasileira como uma realidade.


### [Modelo 2](https://www.youtube.com/watch?v=lUB55zMrsxM)
A constituição federal de 1988, documento jurídico mais importante do país, prevê em seu artigo 6o, o direito a (Eixo Social) como inerente a todo cidadão brasileiro. No entanto, tal prerrogativa não tem se reverberado com ênfase na prática quando se observa o (Tema), dificultando, deste modo, a universalização desse direito social tão importante. Diante dessa perspectiva, faz-se imperiosa a análise dos fatores que favorecem esse quadro.

Eixo Social: educação, saúde, moradia, emprego, transporte, lazer, alimentação, previdência social, segurança,

Em primeiro lugar, deve-se ressaltar a ausência de medidas governamentais para combater o (problema). Nesse sentido, (aprofundamento do argumento). Essa conjuntura, segundo as ideias do filósofo contratualista John Locke, configura-se como uma violação do “contrato social”, já que o Estado não cumpre sua função de garantir que os cidadãos desfrutem de direitos indispensáveis, como a/o (Eixo Social), o que infelizmente é evidente no país.

Ademais, é fundamental apontar o (Argumento 2) como impulsionador do (problema) no Brasil. Segundo (Citação/ Dados do Cotidiano). Diante de tal exposto (Aprofundamento do argumento). Logo, é inadmissível que esse cenário continue a perdurar.

Depreende-se, portanto, a necessidade de se combater esses obstáculos. Para isso, é imprescindível que o (Agente), por intermédio de (Meio/Modo), (Ação) – (Detalhamento) – a fim de (Finalidade). Assim, se consolidará uma sociedade mais (Adjetivo positivo), onde o Estado desempenha corretamente seu “contrato social”, tal como afirma John Locke. Dessa forma, tornar-se-á possível a construção de uma sociedade permeada pela efetivação dos elementos elencados na Magna Carta.


### [Modelo 3](https://www.youtube.com/watch?v=SCnd-ynVNnA&t=419s)
O quadro expressionista “O grito”, do pintor norueguês Edvard Munch, retrata a inquietude, o medo e a desesperança refletidos no semblante de um personagem envolto por uma atmosfera de profunda desolação. Para além da obra, observa-se que, na conjuntura brasileira contemporânea, o sentimento de milhares de indivíduos assolados pelo (TEMA PROBLEMATIZADO) é, amiudadamente, semelhante ao ilustrado pelo artista. Nesse viés, torna-se crucial analisar as causas desse revés, dentre as quais se destacam a negligência governamental e o (ARG 2).

A princípio, é imperioso notar que a indiligência do Estado potencializa o (PROBLEMA). Esse contexto de inoperância das esferas de poder exemplifica a teoria das Instituições Zumbis, do sociólogo Zygmunt Bauman, que as descreve como presentes na sociedade, todavia, sem cumprirem sua função social com eficácia. Sob essa ótica, devido à baixa atuação das autoridades, (APROFUNDAMENTO ARGUMENTATIVO). Nessa perspectiva, para a completa refutação da teoria do estudioso polonês e mudança dessa realidade, faz-se imprescindível uma intervenção estatal.

Outrossim, é igualmente preciso apontar o (ARG 2) como outro fator que contribui para a manutenção do PROBLEMA. Posto isso, de acordo com \*Dados estatísticos/ alusão/ citação... Diante de tal exposto, (APROFUNDAMENTO ARGUMENTATIVO). Logo, é inadmissível que esse cenário continue a perdurar.

Portanto, são necessárias medidas capazes de mitigar o PROBLEMA. Dessarte, a fim de (FINALIDADE), é preciso que o (AGENTE) – por intermédio (MEIO/ MODO) – (AÇÃO) DETALHAMENTO. Espera-se, assim, que os sofrimentos emocionais retratados por Munch delimitem-se apenas ao plano artístico.


### [Modelo 4 (e com a redação que usou o modelo e tirou mil)](https://www.youtube.com/watch?v=7dByrA1RqDk&t=6s)
Na obra “Utopia”, do escritor inglês Thomas More, é retratada uma sociedade perfeita, na qual o corpo social padroniza-se pela ausência de conflitos e problemas. No entanto, o que se observa na realidade contemporânea é o oposto do que o autor prega, uma vez que o (Tema Delimitado) apresenta barreiras, as quais dificultam a concretização dos planos de More. Esse cenário antagônico é fruto tanto do (Argumento 1), quanto do (Argumento 2). Diante disso, torna-se fundamental a discussão desses aspectos, a fim do pleno funcionamento da sociedade.

Nesse sentido, diante de uma realidade instável e temerária que mescla conflitos nas esferas (eixo 1) e (eixo 2), analisar seriamente as raízes e os frutos dessa problemática é medida que se faz imediata.

Precipuamente, é fulcral pontuar que o (Problema) deriva da baixa atuação dos setores governamentais, no que concerne à criação de mecanismos que coíbam tais recorrências. Segundo o pensador Thomas Hobbes, o estado é responsável por garantir o bem-estar da população, entretanto, isso não ocorre no Brasil. Devido à falta de atuação das autoridades, ... (Argumento 1 (Consequência do Problema)). Desse modo, faz-se mister a reformulação dessa postura estatal de forma urgente.

Ademais, é imperativo ressaltar o (Argumento 2) como promotor do problema. De acordo com (Dados do cotidiano/ Citação). Partindo desse pressuposto, ... (aprofundamento do argumento). Tudo isso retarda a resolução do empecilho, já que o (Argumento 2) contribui para a perpetuação desse quadro deletério.

Assim, medidas exequíveis são necessárias para conter o avanço da problemática na sociedade brasileira. Dessarte, com o intuito de mitigar o (Problema), necessita-se, urgentemente, que o Tribunal de Contas da União direcione capital que, por intermédio do (Agente interventor), será revertido em (Ação interventora), através de (Meio/modo) + (Detalhamento). Desse modo, atenuar-se-á, em médio e longo prazo, o impacto nocivo do (Problema), e a coletividade alcançará a Utopia de More.

### ![[Redação da aluna que usou esse modelo em 2021]]
### [Modelo 5](https://www.youtube.com/watch?v=9QowHc0RA78&t=271s)
Na animação “Moriarty, o patriota” é retratado uma crítica à sociedade de classes, em que as mazelas sociais são consequências do comportamento do povo. De maneira análoga, tal conjuntura é retratada no País ao se analisar o **(TEMA)** o qual é um problema resultante da displicência populacional diante do tema. 

Desse modo, constata-se um impasse motivado não só pelo A1, mas também pelo o A2. Em primeiro lugar, a má formação educacional é um agravante do **(TEMA)**. Nesse sentido, segundo o pedagogo Paulo Freire, quando a educação não é libertadora, o sonho do oprimido é ser opressor. Sob esse viés, a premissa sobredita se aplica no contexto brasileiro, pois parte da população devido ao ensino lacunar age **(PROBLEMA LIGADO AO TEMA)**, o que ocasiona **(CONSEQUENCIA DO PROBLEMA)**. Dessa forma, em decorrência de uma falha dos educamos, a problemática perdura no País. 

Ademais, a mídia é mais um fator que agrava a questão. Sob essa perspectiva, conforme o sociólogo Pierre Bourdieu as instituições cujo dever é promover a democracia não devem se converter em instrumento de violência simbólica. Nessa óptica, a mídia a qual não tem o papel de disseminar o conhecimento ao invés de orientar a população no tocante a/tocante ao **(ASSUNTO DO TEMA)** faz-se alienar a sociedade mediante a conteúdos empobrecidos os quais não abordam melhorias ao **(TEMA)** no Brasil. Logo, o setor midiático tem interferência direta na manutenção do problema. 

Portanto, faz-se imprescindível a tomada de medidas resolutivas quanto a/quanto o (**PALAVRAS DO TEMA)**. Para isso, compete ao **(AGENTE)**, cuja função é **(DETALHAMENTO)** por intermédio de/do (MODO/MEIO) a fim de **(FINALIDADE)**. Além disso, o **(AGENTE)** deve **(AÇÂO)** a partir de **(MODO/MEIO)** a fim de **(FINALIDADE)**. Por fim, com essas ações, pode-se ter uma Nação diferente da citada na animação.

### Modelo 6
![[[POXALULU]-EBOOK-MODELO-REDACAO-PRONTA-2.pdf]]