## Porcentagem

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F7ca201bf-be95-407d-81d5-e8fa29a8647e%2FUntitled.png?id=766d2111-f72f-4fe4-b998-5c8d4ac32958&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Imagino que, de longe, a coisa mais importante de saber da porcentagem, seria conhecer sobre suas as possíveis formas de representação. Afinal, em cada situação, tem uma forma que seria mais apropriada em usar (ou também, converter).

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F12cd01d9-d6aa-4aa1-9cce-97663205382d%2FUntitled.png?id=2dc3ea2d-b219-4c94-b54d-4655494ab7c6&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Bem simples para converter e, sinceramente, não tinha esquecido em como fazer. Para transformar de porcentagem para unitária, basta multiplicar em 100, ou vice-versa (de unitária para porcentual, multiplica-se em 100).

### Exemplos

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F28300b4f-f383-471c-89cb-55e8f03a7002%2FUntitled.png?id=97cccceb-8b07-42fb-b857-6f6ba8b25194&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=770&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Isso também lembro bem. Apenas o que não costumo fazer, e estou tentando tornar em hábito, é de cortar os números sempre que possível (nesses do exemplo, então, vira um festival de corta o 0 pra cá e corta o 0 pra lá).

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F803b0bd3-d00d-40b1-ad80-dc7de78ec85c%2FUntitled.png?id=b23afdc2-229e-438e-8504-285ff1a01eda&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=960&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Esse é um outro jeito também possível de descobrir o porcentual de um número - mais fácil e rápido para fazer, porém a dificuldade é ter essa sacada ao ver o problema.

Transformou em fração, simplificou e logo em seguida multiplicou a um número a qual tornouo denominador em 100, ou seja, a porcentagem em fração prontinha para usar.

Ironicamente, lembro de algumas pontuais vezes, durante o fundamental mesmo, que acabei fazendo isso - não por “sacada genial”, percebendo no mesmo instante, mas sim por acaso, quando a fração já estava de um modo fácil de notar isso.

### Aumento Porcentual de um Valor

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F24ba8fa1-5088-45ee-8861-254e3ac3440d%2FUntitled.png?id=f3aa173c-5dec-4680-bd64-d319acfdf0e8&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Apesar de saber, esqueço com frequência e acabo em primeiro descobrindo quando que seria, e só então, somar com o valor… Fico um pouco triste o que a falta de prática pode fazer com uma pessoa - no fundamental, consegui chegar nessa conclusão sozinho, sem ter sido dica de algum professor.

O aumento em % de tal coisa, sempre que dizer ser 100% + esse % de tal valor. Dito isso, ela em forma de fração ou de unitária, pode ser a mais simples para resolver, dependendo do número que está do outro lado.

### Desconto Porcentual de um Valor

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F426e3fe2-daa5-40a3-9d89-c655ab0926d2%2FUntitled.png?id=b108190b-120c-45ab-86fb-2e9514826194&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

A mesma coisa que a anterior - mas agora, subtraindo, como o esperável. O porcentual será = 100% - esse tal %. Pode transformar em fração ou em unidade para calcular - porém, percebo que, em descontos, a forma fracionária costuma ser o jeito mais fácil.

### Aumentos e Descontos Sucessivos

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F26386cf5-ed6f-4286-91de-9798ec16c8c3%2FUntitled.png?id=a9e4491f-9c7b-46d1-bb4a-46e4fca8a1d9&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Basta multiplicar esses aumentos/descontos entre eles mesmos. Isso sim é algo que não sabia (não lembro de aprender na escola, de verdade), e também era trouxa em achar que deveria somar ou subtrair eles…

De qualquer forma, agora referente ao problema desse exemplo, estava pedindo duas coisas:
1. Se foi um aumento ou redução ao valor original.
2. A resposta para a segunda pergunta, é o resultado após simplesmente o uso dessa propriedade e diminuir com o total para descobrir p possível aumento ou desconto.

Enquanto a primeira, como sabemos que o aumento, em forma unitária, ser >1; enquanto o desconto, <1, bastasse prestar atenção nisso para responder corretamente.

