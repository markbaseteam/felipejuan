---
banner: "![[ドット絵.gif]]"
banner_y: 0.79
banner_icon: 🎓
sticker: emoji//1f614
---
<iframe width="380" height="209" src="https://www.youtube.com/embed/58zyjUmoriQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

- **como posso usar o anki para o enem:**
    - memorização de **fórmulas** de matemática, física, química
    - memorização de **conceitos** (por exemplo: escudo cristalino x bacia sedimentar)
    - memorização de **acontecimentos** (por exemplo: Revolta da Vacina - contexto, causas, consequências...)
    - memorização de **dados** (ajuda para redação)
    - memorização de **citações** (também ajuda para redação)
    - memorização de **questões dos ENEMs anteriores** (aquelas que caem muito e, principalmente, as que eu errava)
- **método para resolver as questões de Linguagens / Humanas**
    - Sinceramente, não há muito segredo aqui: **praticar questões**! Muitas.
    - A prova de Linguagens é majoritariamente _interpretativa_. Ou seja, uma leitura atenta do texto e da pergunta deve bastar para acertar a maioria questões.
    - Resolvido _todas_ as questões de Linguagens, de 2009 até o último ENEM. Recomendo que você faça o mesmo. O ideal é errar bastante para identificar possíveis fraquezas na sua preparação. Muito cuidado com:
        - leitura desatenta
        - leitura apressada
        - impaciência...
        - foco na atividade do momento: resolver questões!
    - Quando se deparar com conceitos ou termos desconhecidos, principalmente no comando das questões ou nas alternativas, anote-os para pesquisa posterior.
    - Meu **método para resolver as questões** de Linguagens, na preparação e no dia prova:
        1. ler o **título** do texto
        2. ler a **referência** do texto
        3. ler o **comando** da questão **com _muita_ atenção**
            - é aquele texto que aparece em cima das alternativas, é o _comando_ que estabelece a questão a ser respondida
            - cuidado com termos sorrateiros, como "nunca-sempre", "não", antônimos escorregadios, etc.
            - circule as palavras mais importantes no comando: identifique o que a questão quer saber
        4. ler cada **alternativa**
        5. só agora ler o **texto do começo ao fim**, com atenção, mas sem demorar muito
        6. Anotar a resposta. Caso não tenha encontrado a resposta ou tenha ficado com dúvidas, deixe uma marca nessa pergunta e volte para ela depois
            - o ideal é excluir (riscar) algumas alternativas incorretas nessa primeira leitura
    - Algumas partes são mais conceituais, como Geografia Física — então, não tem escapatória, precisa conhecer esses conceitos porque dificilmente dá para identificar a resposta sem ter esse conhecimento prévio, por exemplo, escudo cristalino e bacia sedimentar, tipos de projeções cartográficas...
    - Ao praticar as questões, anote os assuntos das questões que errar; depois, faça uma pesquisa ou releitura breve sobre aquele assunto.
        - cada pergunta errada é a chance que você tem de eliminar dúvidas, reforçar conhecimentos e aplicá-los no dia da prova.
- **sites com resoluções comentadas do Enem e outros vestibulares**
    - [http://www.bernoulliresolve.com.br/](http://www.bernoulliresolve.com.br/) (ENEM, ITA, IME, UNICAMP, FUVEST, EBMSP, CMMG) 
    - [https://poliedroresolve.sistemapoliedro.com.br/](https://poliedroresolve.sistemapoliedro.com.br/) (ENEM, ITA, IME, UNICAMP, FUVEST, UNESP, UNIFESP, etc.) 
    - [https://www.curso-objetivo.br/vestibular/resolucao_comentada.aspx](https://www.curso-objetivo.br/vestibular/resolucao_comentada.aspx) (todos acima e mais um pouco) 
    - [https://angloresolve.plurall.net/](https://angloresolve.plurall.net/) (ENEM, UNICAMP, FUVEST, UNESP, UNIFESP, Albert Einstein, FCMSCSP) 
    - [https://www.etapa.com.br/home/apoio-ao-vestibulando/etapa-resolve](https://www.etapa.com.br/home/apoio-ao-vestibulando/etapa-resolve) (todos poliedro e mais um pouco, Mackenzie e UFSCAR) 
    - [https://www.elitecampinas.com.br/gabaritos/](https://www.elitecampinas.com.br/gabaritos/) (ENEM, ITA, IME, UNICAMP, FUVEST, UNESP, UNIFESP, AFA) 
    - [https://cursinho.cpv.com.br/cpv-resolve/](https://cursinho.cpv.com.br/cpv-resolve/) (igual etapa) 
    - [https://servicos.aridesa.com.br/provascomentadas/](https://servicos.aridesa.com.br/provascomentadas/) (ENEM, ITA, IME, UECE)

![[🧭 Acesso Rápido]]
