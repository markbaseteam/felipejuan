## Regra de Três Composta

“Envolve mais de duas grandezas” - estou começando essa aula agora, e pela descrição, imagino que seja essencial para a análise dimensional (senão ser ela mesma).

Update: não tem relevância para a análise dimensional 🤡. Não deixa de ser importante, apesar. Etapas:
1. Separar em colunas as grandezas do mesmo tipo;
2. Identificar quais grandezas são diretamente ou inversamente proporcionais (percebe-se a relação direta com a aula anterior);
3. Montar a proporção e, por fim, resolver a equação.

### Questões
![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F2828ce12-9986-43e7-8e55-3f8464bdf74b%2FUntitled.png?id=52f28c75-72b5-4ff4-9034-6c238434dca5&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

**Inverteria apenas a coluna do número de dias.**


![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F2ec8b740-7cbd-453b-ba8b-488d50114291%2FUntitled.png?id=38e411a0-138a-4884-94f0-afe18025e6ff&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

**Inverteria apenas a coluna do número de gatos.**


![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F405f655e-ca83-41d8-b0a6-2de5c9238530%2FUntitled.png?id=c777e700-4b93-432d-a17d-ab67323935ae&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

O número de colunas diretamente/inversamente proporcionais está igual. Portanto, eu escolheria aleatoriamente (ou o que a minha cabeça acharia ser a mais fácil, no momento).

Apenas não esqueça de sempre montar as equações antes, em vez de ir resolvendo tudo, a fim de notar qual pode ser cortado com qual (a coluna da obra, foi a que aconteceu isso logo no começo - cortando o 20 com 20).d

Para identificar cada coluna, é bem simples - na última questão, pode imaginar que, quanto o maior número de operários, e mais horas diariamente trabalhando, menos serão os dias para terminar, e menor a obra deve ficar.

Essas questões são bem padrãozinho: a separação das grandezas em colunas, serve para facilmente identificar qual seria proporcional (ou não a qual), como fala as estapas.

Para montar a equação, a coluna da incógnita será o produto das demais frações. Na equação, deve escolher inverter antes ou as que são diretamente proporcionais, ou as que são inversamente (tanto faz)

Particulamente, prefiro escolher a que leva inverter a menor quantidade de frações possíves. Nas duas primeiras questões, adicionei qual seria, portanto.