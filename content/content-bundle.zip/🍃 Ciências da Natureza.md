
# 🍃 Ciências da Natureza

```start-multi-column
ID: ID_0hs4
Number of Columns: 2
Largest Column: standard
```

> [!tip] Dica 1
> Deixe para formar uma conta gigantesca para depois ir apenas simplificando/cortando. Não faça de pouquinho a pouquinho.
![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F24938c99-6d6f-431a-af9f-96b5fb1736af%2FUntitled.png?id=f7ff3f8a-cd5c-4a2d-80d1-545920227c36&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=580&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

--- column-end ---

> [!tip] Dica 2
> Lembre-se também de cortar as letrinhas.
![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Ff7eb7456-605f-40de-88f8-39e90aa6785e%2FUntitled.png?id=3eb9f3ec-0497-4b0c-9c3e-71bdb3413a43&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=580&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

--- end-multi-column


# 🔬 Biologia

# 🧪 Química

# 🧲 Física
![Macete para Fìsica](https://www.youtube.com/watch?v=mMFAztirczM&t=601s)