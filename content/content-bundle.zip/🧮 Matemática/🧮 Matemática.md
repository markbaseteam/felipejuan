# 🧮 Matemática

> [!tip] #### 💡 Simplifique, Corte, Padronize

## 🪄 Macetes 
### Macete para Alternativas com Só Números

![200](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fe62977be-61cd-4d2a-8e53-e07c7f7f54ba%2FUntitled.png?id=8cc1bf13-c1d5-4be3-aa16-1ef2d530c099&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=470&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Sempre que observar as alternativas serem apenas números, pode eliminar de boa a primeira e a última alternativa, ou seja, a letra A e a E.

Veja ainda se, as três que sobraram, qual delas mais se distancia das demais, para também ignorar, por agora.

O que está fazendo eu confiar tanto nessa estratégia, foi o fato de só duas questões, de 19 assim, que a alternativa correta foi a A ou E.

No mínimo, posso economizar tempo na hora da tentativa e erro. Desconfie se esteve desatento e respondeu em uma delas.

### Macetes de Matemática Básica
#### número que termina em 5 (e ao quadrado)

![|350](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F3b9cdbc4-8c01-46f2-86ea-558bab9c0206%2FUntitled.png?id=077af697-6144-4012-9e18-89d27eaefc8a&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=580&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Transforme a parte do 5 em 25. O restante, multiplique ele mesmo pelo número posterior a ele.

25² = 2 \* 3 = 6 junto com 25 = 625

75² = 7 \* 8 = 56 junto com 25 = 5625

105² = 10 \* 11 = 110 junto com 25 = 11025

#### número multiplicado por 5 / 50 / 500

![|400](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Faa933e55-9b38-4204-801a-38683da8f0b3%2FUntitled.png?id=8c286aee-ac34-4843-aeb8-d72d41e0984f&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=670&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Transforme o 5 em $\frac{10}{2}$ e multiplique por ele. Se for 50 / 500 e assim adiante, lembre-se de **deixar para colocar os 0 no resultado**. Mesmo método é aplicado a eles.

Observe como fica mais fácil e rápido fazendo assim - e também, para resolver de cabeça.

É fácil multiplicar qualquer número por 10. É fácil dividir o número por 2. Por isso que isso é efetivo.

#### número multiplicado por 25

![|400](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F1008b16f-5487-4ea4-8cee-5a63a28def30%2FUntitled.png?id=da44708a-cf27-44ab-8a2a-a9eec6e74273&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=670&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Mesma coisa que a anterior - transforme em fração com um numerador fácil e multiplique por ele em seguida. Essa razão terá exatamente o 25 como resultado.

O motivo de funcionar, é o mesmo que a anterior. Embora, por exemplo, essa fração seja possível simplificar - sendo $\frac{25}{1}$ o menor possível - aqui será a exceção para não simplificar ao máximo, afinal, seria o mesmo.

O segredo para isso funcionar, é de deixar com números fáceis de multiplicar/dividir. E como sabemos, nada é mais fácil que 10 / 100 / e assim adiante.

![|280](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F21003d5c-b3c4-4674-9378-a8fa824c8807%2FUntitled.png?id=5a45b543-0b18-4787-9261-87b9c9fb00f7&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=480&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Transforme divisão em fração. Em seguida, simplifique o máximo possível. Fica bem mais fácil de resolver assim.

Estou acostumado a fazer isso quando o número já está em fração - porém, nunca tinha pensando em fazer isso com divisões normais.

Quando chegar na maior simplificação possível, basta dividir normalmente. Estará em um número com poucas casas; mais simples de resolver.

#### compensação (somar / subtrair só um pouquinho)

![|350](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F1125aaab-c086-4378-8fbe-e18ebf74aa9b%2FUntitled.png?id=3eb2abdf-a916-4be4-b48f-1513eb1dd6f2&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=580&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

![|330](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Ff2e98ee7-c21d-456c-bfa6-203df83576ec%2FUntitled.png?id=b6abc4bd-89e7-4e67-922d-c02f8964dc94&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=380&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Arredonde o número para um que seja mais fácil para o contexto (por exemplo, transformar a unidade igual do outro / tornar a unidade em 0 / fazer que a operação dê 0).

Em seguida, não esqueça de ver quanto que foi somado/subtraído, para adicionar de volta na resposta final (com a operação inversa).

Por texto, admito parece mais complicado do que realmente é. Porém, a imagem anexada mostra perfeitamente o que / como deve ser feito.

#### divisão/multiplicação grande > propriedade distributiva

![|330](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F3d7110e8-cb0a-4de2-abfb-6e823cb38da2%2FUntitled.png?id=cc16670f-846a-4c2f-b11d-47a0090f6be8&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=380&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

![|400](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fbda65e8b-77ea-4287-b823-9b5ee82ee826%2FUntitled.png?id=f9b45343-3134-4a27-8e60-b0981960ac68&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1850&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

![|280](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F9678e02e-3569-48af-a26b-fa9a4ebc2cab%2FUntitled.png?id=6310e18c-653c-41b3-a22b-93372b7f25a1&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=480&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Veja que, aqui, a fim de deixar redondinho (terminasse em 0), compensei um pouco, mais uma vez, facilitando.

794 é o mesmo que 800 - 6.

![|400](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fa8626990-df62-4056-b649-e2f0539e5c62%2FUntitled.png?id=2fc91f29-fb68-4ede-921d-1a94926226a3&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=570&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

\-12 é o mesmo que -10 - 2.

Em números grandes assim, transforme em propriedade distributiva em números redondinhos e manter a tal operação.

Dessa forma, fica bem mais fácil de multiplicar, ou dividir (as duas operações são válidas, lembrando de fazer para ambos os números).



## 📕 Caderno de Questões
- ✅ Enem.2020.2.AM5 - Questão 143
	![|350](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F7e9b9eae-5b79-4c5f-a2db-c33a2b286eae%2FUntitled.png?id=e0bd004a-fad8-476f-a9fb-512f9047eef4&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=580&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	Sem segredo aqui (porém sublinhar, ou reescrever o tal valor do enunciado, no caso, o de 15 sacos de cimento, é bom, visto que na primeira vez, ignorei totalmente por eu estar enferrujado… bem, é a primeira questão do enem que faço dessa lista)
	
	Só lembrar que o cara quer comprar 15 sacos de cimentos, logo terei que multiplicar pelo valor dele em cada depósito. Após isso, também terei a distância entre os dois, e mais uma vez, apenas multiplicar com cada seu respectivo valor e, por fim, somar os dois:
	
	a) (15 ∙ 23) + (1 ∙ 10) = 355 reais.
	
	b) (15 ∙ 21,50) + (3 ∙ 12) = 358,50 reais.
	
	c) (15 ∙ 22) + (1,50 ∙ 14) = 351 reais.
	
	d) (15 ∙ 21) + (3,50 ∙ 18) = 378 reais.
	
	e) (15 ∙ 24) + (2,50 ∙ 2) = 365 reais.
- ✅ Enem.2020.2.AM5 - Questão 151
	![|330](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fd54e0bed-6051-483a-8669-7baa109a2da2%2FUntitled.png?id=c5f131e1-5897-4011-8dd5-beabcd265d56&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=480&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Mais uma questão que não tem segredo - quanto maior o resultado (ou seja, a razão entre esses dois número, no caso), maior é a produtividade. Portanto, a) Dia 1: 8004\=200\\frac{800}{4}=200
	
	b) Dia 2: 100008\=125\\frac{10000}{8}=125
	
	c) Dia 3: 110005\=220\\frac{11000}{5}=220
	
	d) Dia 4: 18009\=200\\frac{1800}{9}=200
	
	e) Dia 5: 140010\=140\\frac{1400}{10}=140
- ❌ Enem.2020.2.AM5 - Questão 153
	![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fc272f857-2725-4a0b-9aba-82b63bd5f953%2FUntitled.png?id=b71866c9-ac90-48ec-b746-be70b9effc1d&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1920&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	Marquei D (um inútil mesmo.)
	
	Multiplicação, Soma e Raciocínio Lógico… Ou aritmétrica, mesmo. ![🤡](data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==)
	
	Em minha defesa, não prestei atenção e fiz a questão 153 de 2020, enquanto deveria ser de 2018 (não estava preparado para uma questão de aritmétrica).
	
	De qualquer forma, é algo ainda poderia acertar, se estivesse acostumado e com alguns insights previamente em minha mente.
	
	Achei genial que calculou casa por casa da questão. Ou seja, viu quanto que tinha na casa da centena, dezena e então, unidade. Depois só somou tudo mesmo.
	
	A única coisa que sabia, é que teria multiplicar 3 vezes… Mas não sabia exatamente o quê.
	
	Esqueci totalmente que teria 100 só por conta da casa dos 200.
	
	Multipliquei elas por 9, em vez de 10, achando que deveria desconsiderar quando se repetia (como 122). Não é um caso que preciso fazer isso (confundi com conteúdo de Análise Combinatória).
- ❌ Enem.2017.2.AM5 - Questão 151
	![|250](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F33158e80-4515-41b8-9607-afc7de69040b%2FUntitled.png?id=06a2b480-30d6-4e39-a7c6-2bf4acc96a02&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=960&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	![|250](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fcdd92895-e372-4a3b-ab24-50c6f1cd46ae%2FUntitled.png?id=8d025d74-700f-4131-94c3-6cb6b5ab131c&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1270&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Não Marquei: achei que seria necessário fazer algo com “1,96”. ![🤡](data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==) 
	
	Pelo menos, se eu soubesse disso, mesmo do jeito que estava resolvendo a conta (não incorretamente, porém demorada), chegaria na resposta correta.
	
	A minha lição é: Simplifique. Padronize.
	
	É bem mais fácil resolver frações, depois de simplificar ao máximo que pode. Nesse caso, a simplificação também deixará o numerador igual, assim permitindo uma comparação mais fácil.
- ✅ Enem.2017.2.AM5 - Questão 164
	![|300](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F2686fa53-c6ba-48e5-a3ae-f06479f622a6%2FUntitled.png?id=5336a8ac-31c0-4955-9e8d-434534c1b8b0&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=580&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Números decimais e Subtração.
	
	Essa tipo de questão, é bom não fazer na pressa. O contrário, não é difícil erra por besteira - assim como foi a minha primeira tentativa nela. Contudo, é mais uma que, pelo menos, pode se sentir confortável em eliminar as alternativas (fácil de identificar quais são impossíveis de ser).
	
	Uma das poucas questões, pelo menos, até o momento (bem no começo), que consegui entender exatamente toda a intenção dela (e quando falo intenção, também quero incluir a escolha de tais alternativas, a fim de confundir o candidato e como faria isso).
	
	a) 3,099 - 4000 = 0,901 
	b) 3,970 - 4000 = 0,030 
	c) 4,025 - 4000 = **0,025** 
	d) 4,080 - 4000 = 0,080 
	e) 4,100 - 4000 = 0,900
- ❌ Enem.2017.2.AM5 - Questão 166
	![|600](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F49289cc1-9e4a-4dba-8909-8dd0e0ef5654%2FUntitled.png?id=ac678dfe-8690-437e-8eb2-d068292b5f3f&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Marquei B. Fiquei entre essa e a D mesmo - porém, eu não sabia se o quociente deveria ser o menor ou o maior possível.
	
	Meu problema aqui foi em interpretação. Se desde o começo soubesse disso, acredito que eu não seria trouxa de ficar fazendo conta para verificar - só pela razão, seria o suficiente para matar a questão logo no começo.
- ✅ PPL.2020.2.AM5 - Questão 148
	![|350](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fa77f9bc4-ef19-4eca-8b20-fa86fe3851e8%2FUntitled.png?id=e1f18b85-cc2d-4c16-8738-def410a53403&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=670&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Só de cortar os 0, de longe, é possível ver que Malta é o país com a maior densidade demográfica. Quanto maior a razão, ou seja, “o resultado dessa divisão”, maior será a densidade.
- ✅ PPL.2020.2.AM5 - Questão 154
	![|400](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F4b89acb8-44b1-4154-bd4c-f3ef2e891e14%2FUntitled.png?id=89386dca-999e-4783-beeb-0214422124c9&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=860&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Existem diversas formas diferentes para se resolver essa questão. Depois de reaprender matemática básica, quis calcular quantos minutos gastam em um dia, e após, converter em horas, por ser a unidade de tempo sobre o consumo no banho.
	
	Todavia, como as alternativas são distantes uma das outras, seria possível eliminar algumas, só de fazer algumas contas simples, lendo o enunciado, a quais te dariam uma boa noção.
	
	Por exemplos, 5 pessoas \* 2 banhos = 10 banhos/dia, correto? Multiplicando por 15, notaria que são 150 minutos diariamente, ou também, 2 horas e meia. Certo, até aqui, também poderia ser algo que escreveria no papel no lugar, em vez de fazer exclusivamente na cabeça.
	
	Porém, em vez de fazer a multiplicação com números grandinhos, como 540 litros, que bem pouca gente tentaria de cabeça na hora da prova, basta, por exemplo, arredondar para 500, e o tempo diário, para apenas 2 horas.
	
	Nesse caso, poderia concluir que eles gastam um pouco mais de 1000 litros por dia - assim, sendo absurdo as duas primeiras alternativas. Como está pedindo em meses, multiplicando por 30, que é uma conta super fácil, conclui que são gastos mais de 30000 por mês.
	
	Para a nossa sorte, a única alternativa que é acima disso, é a letra E. Portanto, seria possível economizar tempo nessa conta, em vez de fazer contas mais demoradas, só de descobrindo o aproximado, devido às alternativas com valores distantes.
- ✅ PPL.2020.2.AM5 - Questão 155
	![|400](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F69dbff94-81b3-4a8c-8e31-f69d34a631c0%2FUntitled.png?id=2ba9d0d2-d094-4563-96b9-87b14d2ed85c&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=580&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Essa taxa do táxi, por ser fixa, ou seja, aplicado a todos, é irrelevante adicionar na conta. O que será considerado mesmo, são o preço que o táxi cobra por quilômetro quadrado + a diária, claro.
	
	Dito isso, vamos ver do primeiro hotel, a qual é o único que a distância em km não está em decimal (mais fácil de fazer conta):
	
	R$180 + (R$2,5/km \* 7km) = R$180 + R$175 = R$197
	
	Agora, comparando diretamente com o preço dos demais hotéis, perceba que só a diária de alguns é mais cara que o total desse hotel. Ou seja, não é necessário fazer a conta para descobrir se será mais cara ou não.
	
	Assim, eliminamos as alternativas do H2, H3 e H5. Mas calma lá - veja que não foram todas as demais - ainda sobrou uma, que é do H4.
	
	Podemos muito bem, agora apenas descobrir o preço desse hotel normalmente, calculando cada coisinha. Porém, isso demanda tempo, então, assim como fizemos na questão anterior, também podemos aplicar aqui - arredondar de leve tal número de um jeito que a operação fique mais fácil.
	
	Dessa forma, podemos arredondar a distância de 1,5km, para 2,0km, e fazer o restante da equação:
	
	R$190 + (R$2,50/km \* 2km) = R$190 + R$5 = R$195
	
	Perceba que, mesmo deixando a um valor mais alto do que é, ainda assim, conseguiu ficar menor do que o outro. A partir disso, podemos dizer, com tranquilidade, que o preço do H4 é menor do que do H1.
- ❌ PPL.2020.2.AM5 - Questão 158
	![|400](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Feffb0b34-172c-4f03-827b-ee0ce4592e11%2FUntitled.png?id=848f9db8-5572-40de-8039-f0c12685ecc7&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=670&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	O meu vacilo foi antes não ter visto a diferença de casa entre os dois valores, na ora das operações. Calculei como se os dois estivessem na mesma casa unitária, e errando por não igualar a antes na resposta final.
	
	Veja que para o 0,0025 ficar na mesma casa do 0,30, teria que avançar duas casas / multiplicar por 100 / 10². Tenha isso em mente, ou para já calcular com essa diferença, e ter que o resultado prontinho, sem ter que fazer mais nada, ou para corrigir no final.
	
	Enfim, ao ver esses valores, de cara, soube que o da água seria mais fácil se dividisse a coluna do gasto por 4. Afinal, multiplicar lembrei que multiplicar por 0,25, é a mesma coisa que multiplicar por 25/100 > 1/4 . O ideal seria dividir por 400, porém como eu não gostaria de ter trabalhos com vírgula numa divisão, achei melhor por isso mesmo.
	
	Enquanto no valor da energia, percebi que, por ser apenas 0,30, seria bem mais simples se apenas multiplicasse mesmo, do que dividir. Agora, uma coisa que eu deveria ter prestado atenção:
	
	Levando como base, o que fiz com o valor de água, e a diferença original entre os dois, eu deveria ter multiplicado por 300 (ou só 30, se desconsiderasse as vírgulas do consumo de energia, afinal, avancei só uma casa para que ficassem sem).
	
	Bem, por ser uma multiplicação e de um número que ainda não é grande, seria de boa para apenas multiplicar normalmente. Porém, se quisesse mesmo multiplicar apenas por 3, seria necessário atualizar o resultado com os 0, posteriormente.
	
	Por fim, bastasse apenas somar ambos e ver qual seria o menor. Diferente de outras questões do mesmo tipo, aqui os valores ficaram bem próximos, então, infelizmente, não seria possível eliminar alternativas sem calcular cada uma.
	![|400](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F622bec07-c85a-4fee-a3cd-47126f9a2995%2F2023_06_12_17_49_Office_Lens.jpg?id=ba643f9b-812c-4f8c-9f6d-7d13c5be42a2&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
- ✅ PPL.2020.2.AM5 - Questão 159
	![|500](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F2bc9d533-cecf-49dc-9d3c-59dfd666c588%2FUntitled.png?id=409737fe-3122-4b8b-938c-3e5ff30e7014&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=860&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	A questão mais fácil do ENEM que vi até agora - nível do fundamental, mesmo, Se o número acima será a quantidade de 20 unidades de tal número, basta dividir ele por 20 para descobrir “quantos 20 cabe nele”.
	
	E o que sobrar, a qual foi 19, se torna o número de baixo.
- ❌ PPL.2019.2.AM5 - Questão 149
	![|550](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F29ed6fb2-7e7d-4f55-94ca-b9de6334160c%2FUntitled.png?id=10dad269-580c-472c-a74b-8c0fa21e8d61&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=860&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	![|550](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F1a309a05-d504-4d51-bab8-61685b6d2127%2FUntitled.png?id=b4fbb4f7-d9ab-43fd-9082-e6aad8057395&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=860&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Poderia ter matado essa questão de uma forma rápida e fácil, se tivesse notado a “técnica” que aprendi em Razão e Proporcionalidade se aplicado aqui. Também, foi o meu erro não perceber que as tais grandezas são inversamente proporcionais e, portanto, o resultado apenas poderia ser errado, do jeito que fiz.
	![|450](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fa75d22aa-931e-41ea-8357-34b32657cfa9%2FUntitled.png?id=3420a6e6-9fad-4cc7-9a43-a000c4076d6f&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
- ✅  PPL.2018.2.AM17 - Questão 143
	![|600](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F2faa28a6-8d81-4e5a-884d-d63e5c41b521%2FUntitled.png?id=7b21f6aa-0ba5-420f-a4e5-ec2f13f74f9d&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1650&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Bem de boa. Prestei atenção no enunciado e fiz com calma.
	
	![|450](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F5238ec46-bd23-4c6b-8054-27743f91733a%2F20230618_124312.jpg?id=f4c3940a-8e7a-4572-bcd5-9aef7fd841ce&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
- ❌ PPL.2018.2.AM17 - Questão 146
	![|450](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F3e609c37-bf09-4044-9ba8-7b99eab85640%2FUntitled.png?id=f8f7c0d4-bdde-421a-b588-5acc478207dc&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=770&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Por conta das questões anteriores, tive o raciocínio correto para essa questão - como as demais características dos satélites são iguais, com a exceção da distância, poderia descartar as alternativas B, C e D - independente do que fossem pedir.
	
	Além disso, “quanto maior o divisor, menor será o resultado”. Ou seja, conforme a fórmula, a força é inversamente proporcional a distância. Quanto menor a distância, maior será a força.
	
	Contudo, ainda consegui me bananar pensando tudo só na minha cabeça. ![🤡](data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==) Fiquei apenas olhando para a questão; aquele “mais próximo” e não concluí ser com o menor valor para a distância.
	
	Essa vai para a caixa das questões erradas por falta de atenção - mas que poderiam ser evitadas se passasse parte dos meus pensamentos no papel - mesmo não sendo contas.
- ✅ PPL.2018.2.AM17 - Questão 164
	![|300](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F31e3cd72-b0ae-4e14-a243-11ce8d3b0c29%2FUntitled.png?id=a1f79895-b6aa-40ee-8d8f-25de79b57632&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=860&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Mais uma equação que eu poderia ignorar apenas os demais valores da função, afinal, são constantes e a questão apenas está pedindo qual a maior/menor, novamente.
	
	Dito isso, as funções seriam E = B \* H | C = E \* P (população de peixes)
	
	Lago I: E = 5 \* 5 = 25 | 250 = 25P >>> P = 10
	
	Lago II: E = 6 \* 10 = 60 | 300 = 60P >>> P = 5
	
	Lago III: E = 4 \* 5 = 20 | 180 = 20P >>> P = 6
	
	Lago IV: E = 3 \* 7 = 21 | 215 = 21P >>> P = 10,2
	
	Lago V: E = 3 \* 10 = 30 | 220 = 30P = P = 7,3
- ✅ PPL.2018.2.AM17 - Questão 168
	![|400](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F1c1f351f-ae9a-447d-9799-a40dd4de6b19%2FUntitled.png?id=3265a4b1-2fba-425a-9704-729bcad294ef&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=960&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Jogador A = 3G + 1B + 1A + 4V
	
	81 + 9 + 3 + 4 = 97 pontos (![🥉](data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==))
	
	Jogador B = 2G + 4B + 0A + 9V
	
	54 + 36 + 0 + 9 = 99 pontos (![🥇](data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==))
	
	Jogador C = 1G + 5B + 8A + 2V
	
	27 + 45 + 24 + 2 =98 pontos (![🥈](data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==))
- ✅ PPL.2017.2.AM5 - Questão 145
	![|300](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F975b5bbd-0bcd-4291-8449-d9abe665d470%2FUntitled.png?id=b679148a-c750-478c-8303-44e3c24576a4&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=670&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Empresa I: 300 + 200 = 500
	
	Empresa II: 210 + 300 = 510
	
	Empresa III: 360 + 150 = 510
	
	Percebemos que a primeira empresas é a mais econômica para o turista X. Portanto, ao observar as alterantivas,, podemos ficar apenas com as letras A e B.
	
	Empresa II: 70 + 146 = 216
	
	Empresa III: 120 + 72 = 196
	
	Não foi necessário perder tempo calculando como que ficaria com a primeira empresa, pois nenhuma das alternativas restante tem ela como possibilidade.
	
	Portanto, as empresas mais econômicas para os turistas X e Y, respectivamente, são a Empresa I e III. Alternativa B.
- ✅ PPL.2017.2.AM5 - Questão 170
	![|350](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fd464096e-5a96-4ba0-8c91-27a3e229b720%2FUntitled.png?id=a69321de-f156-440e-bd24-26ee1b8888cc&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=860&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Percebemos o quão distantes estão os valores. Portanto, podemos arredondar eles levemente.
	
	Também, de acordo com o enunciado, terá intervenção aquela com o maior produto entre o nível de contaminação e o tamanho da população.
	
	Delícia = 40 \* 2500 - 10.000
	
	Salgada = 50 \* 2500 = 12.000
	
	Vermelha = 60 \* 150 = 900
- ✅ PPL.2017.2.AM5 - Questão 174
	![|350](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fc05bc61f-94b1-45b8-9e5a-8dfd088e2240%2FUntitled.png?id=a40d228f-bd6f-466b-9ea1-6838e1ce5fa9&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=670&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Por conta dos números quebradinhos, mais uma vez, vamos arredondar. É outra questão que é irrelevante ter uma resposta ‘exata’ - ser bem próxima, é o suficiente.
	
	Plano A: 190 - 150 = 40 >>> R$30 + R$0,40 \* 40 = R$30 + R$16 = R$46
	
	Plano B: R$35 (é mais que o suficiente para ele; o valor excedente é irrelevante)
	
	Não é necessário continuar, pois os planos posteriores vão ficando apenas mais caros e bem mais do que ele precisa. Com base nesses três planos, o mais em conta, para o consumidor X, é o plano B.
	
	Portanto, elimina-se as alternativas A e B
	
	Plano B: 450 - 250 = 200 >>> R$35 + R$0,10 \* 200 = R$35 + R$20 = R$55 Plano C: R$60
	
	Ou seja, mesmo pagando pelo consumo excedente, ainda compensa mais o plano B do que o C.
	
	Analisando as alternativas mais uma vez, vemos que, as únicas que têm B e B respectivamente, é a letra C. Dispensável calcular o consumo do consumidor Z.
- ✅ Enem.2020.2.AM5 - Questão 147
	![|350](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F962af3d8-5736-46c8-a770-859c7f97bafd%2FUntitled.png?id=b9e1c6e8-1ff3-4a24-894e-5528b7e34bd4&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=770&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	1 micrômetro = milionésima parte de um metro. ou seja, 1/1.000.000, ou também, 0,00.000.1.
	
	Essa escultura tem tem 100 micrômetros. que multiplicando por 0,00.000.1, será 0,00.010.0, ou também, 0,0001.
	
	Lembrando que a notação científica, nesse caso, o expoente é a quantidade de casas que pulou para trás, só pode ser 10^-4. Alternativa C.
- ❌ Enem.2019.2.AM5 - Questão 144
	![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F1f88aebe-8f93-4f41-836b-95f9ae75498a%2FUntitled.png?id=6b15382f-c4fb-45f2-a8d9-89c2efa9998a&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1650&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Fiquei perdidinho nessa questão. Não foi falta de atenção, mas apenas não consegui interpretar corretamente, mesmo.
	
	Por exemplo, não caiu a ficha que a duplicação do tempo de espera seria apenas a partir da segunda tentativa (ou seja, a primeira será apenas 60 segundos normal).
	
	Fora isso, a informação no enunciado de “30 segundos tempo gasto para cada tentativa”, isso quer dizer que preciso lembrar de somar ele a cada uma - assim como o de espera.
	
	Por fim, além do erro besta de não ter sacado que é para somar, também não percebi que deveria parar de conta o tempo de espera na terceira tentativa; afinal, foi na quarta tentativa que ela acertou.
	
	Como foram 4 tentativas, o tempo gasto normal foram 4 \* 30, portanto, 120 segundos.
	
	Agora, sobre o tempo de espera (que não tem como só multiplicar, pois cada os valores serão diferentes):
	
	1ª Tentativa: 60 segundos
	
	2ª Tentativa: 60s \* 2 = 120s
	
	3ª Tentativa: 120s \* 2 = 240s
	
	Somando os dois tempos diferentes:
	
	420s de espera + 120s gastos fora isso = 540 segundos.
- ✅ Enem.2019.2.AM5 - Questão 168
	![|350](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fbbebd2ee-8c88-4c83-91fb-9703b7544101%2FUntitled.png?id=ee26d5bc-b1cb-41b8-bcd8-c344b39707bd&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=860&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Acredito que dispensa fazer toda a conversão?.. Tendo um bom senso e sabendo do básico, poderia acertar essa questão rapidinho sem escrever qualquer conta.
	
	1cm = 500cm, ou também, = 5m. Dito isso, sabemos que a altura (vendo de cima), seria 9 \* 5m = 45m.
	
	Se o comprimento é 73m, então o valor em centímetro será apenas levemente maior ao de 9cm.
	
	Analisando as alternativas, vemos que a única possível para isso, é a alternativa C. Todas as demais passam bem longe dela, de alguma forma.
- ✅ Enem.2018.2.AM5 - Questão 151
	![|400](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F54700827-5648-4bf2-8fb1-0a98dcbe7490%2FUntitled.png?id=b071f4dd-f468-4945-9815-a2473b73836e&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=860&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Essa tive orgulho de acessar hehe ![🤠](data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==). Apesar de não ser particulamente difícil, isso mostra que estou dominando o assunto de proporcionalidade - que é algo a qual cai bastante no ENEM, além de, antes de tudo, ser algo que tinha dificuldades.
	
	Como o próprio enunciado deixou claro,
	
	Força ![🐟](data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==) massa (quanto maior a massa, maior a força)
	
	Força ![🐟](data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==) 1/r² (quanto maior o raio, menor a força)
	
	Destarte, ao observar o gráfico, veja como o B é o que está mais distante a direita de todos sobre o valor da massa. Ou seja, sabemos que é o que tem o maior valor e, portanto, a maior força.
	
	As Forças A e C têm o mesmo valor de massa - entretanto, perceba que o valor de raio é diferente - do C é maior que do A. Em outros outros, faz com que tenha a força menor.
	
	Colocando em ordem, seria que nem está a última alternativa.
- ✅ PPL.2020.2.AM5 - Questão 143
	![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F73c33756-4485-447f-b798-36a93979d973%2FUntitled.png?id=95566a1d-30d3-4b15-9ab6-dbca48bdbf7a&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Sem comentários. A questão mais simples e fácil até agora. Até que não é familiarizado com “trilhões”, poderia tirar conclusão no momento, apenas por conta do nome.
	
	Para evitar qualquer confusão, basta escrevendo o número até chegar no trilhão. Adicionando de três em três zeros.
- ✅ PPL.2019.2.AM5 - Questão 138
	![|300](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F8c3d2633-fd08-4675-a6fe-a351503b145a%2FUntitled.png?id=439b9801-e743-4b29-8c19-61112a3bd2df&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=670&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Essa questão está querendo que antes a gente descubra o valor de dezembro. Ela será o mesmo da média dos valores anteriores.
	
	(700 + 2500 + 2500 + 2700 + 2800) / 5 = 11200 / 5 = 2240
	
	O valor de dezembro foi de 2240, o que seria uma redução de 460 em relação ao mês anterior. 2700 - 2240 = 460.
	
	Também foi dito que essa mesma redução continuou a mesma pelos os próximos meses. Portanto, apenas precisamos descobrir qual é o mínimo necessário até ficar menor do que 700, o valor do pior mês até então.
	
	2240 - 700 = 1540. Esse é o quanto que precisamos diminuir até chegar lá.
	
	1540 / 460 = 3,3sadadsa. Seria necessário apenas um pouco mais de 3 meses até chegar lá.
	
	Por estarmos tratando de meses, não podemos arredondar pra baixo e apenas pegar a mês que chegaria assim. Tem que considerar como 4 meses, nesse caso, a qual, por ser dezembro, cairia no mês de abril.
- ✅ PPL.2017.2.AM5 - Questão 141
	![|400](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fd7ee84e6-7f48-4cd6-821d-fd3f96e69fc7%2FUntitled.png?id=f21282ea-318b-412d-aa73-c15ab27b75b6&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=770&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Essa é uma questão que bati o olho e já tinha 100% de certeza qual alternativa ser. ![🤓](data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==) Ou era isso que eu queria dizer kkkk
	
	O meu primeiro notebook que tive tinha justamente um HDD de 500GB, e de longe, o valor que mais me parecia familiar, era da letra A mesmo.
	
	Junto a isso, qualquer um descartaria as duas últimas alternativas, por não ser menor que o tal valor, e se fosse um pouco mais atento, também a C, por de cara não ser um número a base de 2.
	
	Mesmo assim, como a minha memória não estava tão íntriga, e essa maldita segunda alternativa parecer familiar, não tive 100% certeza se era isso mesmo ou as minhas lembranças estavam engando a mim.
	
	Na dúvida, fiz regra de três e cheguei no valor aproximado mesmo (mas claro, não sem antes errar uma divisão por besteira.)
- ✅ Enem.2020.2.AM5 - Questão 155
	![|400](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fb46a4285-c611-47d0-a197-8c457bb90f9f%2FUntitled.png?id=c5ce3059-40d9-476e-86cd-ff426e0837cf&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=960&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Meh. Somando as porcentagens, dá para perceber ser levemente acima de 50%, do total de jovens (363 mil), e como as alternativas são relativamente distante das outras, a única que encaixa nisso é apenas a C mesmo.
- ❌ Enem.2020.2.AM5 - Questão 160
	![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F6b7804dc-d6bc-40a5-9333-ffee9efea986%2FUntitled.png?id=f21f95aa-9c08-4296-b89f-0543a5855495&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Não consegui entender como diabos seria essa fórmula. Quero dizer, sabia que seria a soma entre resultados de multiplicações - mas não tinha certeza quais multiplicações seriam essa.
	
	Nesse caso, não notei que seria o produto da probabilidade de chuva (70%) com o EC da chuva, e a probabilidade de não chover (30%) com o ED de sem chuva. Simples assim,
- ✅ Enem.2020.2.AM5 - Questão 164
	![|400](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fcb2e3885-233a-4c0f-9086-f4ff1f2093a1%2FUntitled.png?id=d8b3741f-b4e2-410a-a0d3-1e5ae2daa15a&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=580&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Temos várias coisas que temos para calcular/observar aqui.
	
	Percebemos que o tempo de estudo é 0,6/4anos.
	
	Também, que o tempo médio é de 16 anos, e que gostaria de chegar 70% disso, que seria 11,2 anos.
	
	Até em 2007, já foi avançado para 7 anos, logo seria necessário apenas o avanço de mais 4,2 anos para isso.
	
	Por fim, para saber em que ano chegaria, podemos realizar essa equação aqui:
	
	4,2\=0,644,2 = $\frac{0,6}{4}$
	
	Realizando as contas tudo bonitin, perceberá que o tempo de anos no total até ter esse aumento é de 28 anos. Somando o último ano de pesquisa, ou seja, 2007 + 28, perceberá que o tal ano será apenas em 2035. Ou seja, alternativa D.
- ✅  Enem.2020.2.AM5 - Questão 167
	![|290](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F782ed97f-a1db-47ea-9b7d-f87f106b7335%2FUntitled.png?id=e203a7a8-c25d-4eba-8b5b-d157f9d3f3e1&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=290&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Fiquei com preguiça de calcular a porcentagem certinho e notei que não seria necessário. Arredondei todas elas numa casa da unidade e multipliquei apenas pela unidade dela, como se, na verdade, fossem apenas 10 vendas no total.
	
	Para mim, essa foi a forma que pareceu o mais rápido e fácil a resolver essa questão:
	
	Perfume I: 200 \* 1,0 = 200
	
	Perfume II: 170 \* 1,0 = 200
	
	Perfume III: 150 \* 1,5 = 225
	
	Perfume IV: 100 \* 3 = 300
	
	Como um deles obteve um resultado bem distante dos outros, e sendo justamente o que a gente queria, não foi necessário fazer “observações” neles (por exemplo, que do Perfume I seria, na verdade, levemente maior do que o resultado dado).
- ✅ Enem.2020.2.AM5 - Questão 174
	![|400](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F69762578-2ad5-4171-8d7f-9a051a60fb2f%2FUntitled.png?id=1fe0b06b-6b71-4927-bfb4-e009611295c7&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=960&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
	
	Calculei quanto seria o valor unitário de cada. Da internet, seria 24, e da mensalidade escolar, 70.
	
	Somei ambos e descontei na mesada do filho (pois é o que a família faria mesmo…). 400 - 94 = 306. Após isso, apenas fui realizar a clássica regra de três.
	
	306\=400100306=\\frac{400}{100}
	
	O resultado dessa brincadeira é 76,5 - que representa o porcentual total da nova mensalidade do filho. Porém, queremos saber o porcentual da redução. Para isso, basta subtrair de 100, a qual terá 23,5% como o resultado final.

## 🗿 Matemática Básica
	[[MMC & MDC]]
	[[Frações (transforme tudo em fração)]]
	[[Expressões (ou também, corte e simplifique)]]
	[[Potenciação]]
	[[Radiciação]]
	[[Fatoração - Produtos Notáveis]]
	[[Propriedade Distributiva]]
	[[Frações Algébricas]]
	[[Expressão do Segundo Grau]]
	[[Razão e Proporcionalidade]]
	[[Regra de Três Composta]]
	[[Juros Simples]]
	[[Juros Compostos]]
	[[Porcentagem]]
