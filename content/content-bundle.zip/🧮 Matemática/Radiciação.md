## Radiciação

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F35b80573-8af7-4fed-9e59-43e58e20f94f%2FUntitled.png?id=73338d76-8953-4703-a221-842b61f06a0e&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=580&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

**Se eu fosse para explicar o que é cada um:**
- O índice será o numerozinho por fora, logo do lado esquerdo dele.
- Radical será o famoso símbolo que parece um V com um teto.
- O radicando, o número que fica dentro desse V com teto.
- Finalmente, a raíz é o resultado da radiciação.
### ⚠️ Cuidados

> [!warning] Atenção 1
Se o numerozinho da índice for par, obrigatoriamente a raíz tem quer ser igual ou maior que zero. Ou também, não pode ser um número negativo. Se o numerozinho da índice for par, simplesmente pode ser qualquer número real.
![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F62a1a01d-6f36-4f63-a8fc-ecf5b2dc911f%2FUntitled.png?id=6c781788-d7eb-48b0-9da8-4b166228fb84&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
Por exemplo, sabemos que √-4 é impossível. Mas ³√-8 é possível, assim como ³√8 também é e com o mesmo ‘resultado’ - apenas um sendo negativo, e o outro positivo (-2 e 2).

> [!warning] Atenção 2
Atenção especial para quando o for um situação que pode cortar o índice com o expoente (forem o mesmo número) - mas o radicalizando for negativo - por cortar, mas deixe em módulo antes ou parte direto para o resultado.
![|500](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fe500148c-773d-4f8e-86bf-785c3cc7c115%2FUntitled.png?id=0024df34-ecd8-489c-b7c2-3a03b983c457&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
![|380](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F177cc0f7-c48e-4b4e-8909-6d9067c652da%2FUntitled.png?id=44a02661-101e-4419-80ab-76dc3a19718b&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=480&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

### Propriedade 1 - Raiz/Fração

Gosto de pensar que o numerozinho mais alto vai para a parte de baixo e vice-versa, dependendo de qual para qual está transformando.

![|500](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fb6310a3b-b0c5-4b43-af6a-1bebda82934e%2FUntitled.png?id=c58116f8-21af-4628-8204-86b17f9602f8&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1960&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

![|450](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fbc3ccf93-b21e-465f-b0b8-417377b3c0c5%2FUntitled.png?id=8a1ca2ca-6cc9-4aa9-b1a1-24a37339ac52&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1950&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

### Propriedade 2 - Multiplicação entre Raizes

Basicamente, fazer só a tal operação entre os radicandos dentro da raiz.

![|650](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F75d4a1da-48fa-4430-b6e0-8218599d02a2%2FUntitled.png?id=e0aa62e0-8beb-4785-8c11-aea4a23b620d&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

### Propriedade 3 - Divisão entre Raizes

Basicamente, fazer só a tal operação entre os radicandos dentro da raiz.

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fe52513f9-7f3e-4313-a3a1-2ffb870e7703%2FUntitled.png?id=ce92d262-a42d-410d-9350-a0a4da816740&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1240&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

### Propriedade 4 - Potência da Raiz

Mais uma vez, a nova ‘operação’ sendo apenas para o radicando.

Isso serve para saber que tu pode perfeitamente trazer esse expoente para ele.
 
>💡**Dica:** Usando a Propriedade 1, pode resolver isso de uma maneira mais fácil e rápido.

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fc9c88bd1-333c-445e-bccc-721e155b6326%2FUntitled.png?id=9be4431a-5593-4756-aabd-929f7facd18e&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Algo interessante que eu não tinha reparado, que o quociente, na verdade, pertence ao lado do que será o dividendo (ou seja, o maior número, nesse caso).

Por exemplo, já sabia que, normalmente, vira o expoente do radicando mesmo. Porém, nota-se que pode virar o índice, quando ele for o dividendo.

### Propriedade 5 - Raiz da Raiz

Agora sim, finalmente algo que acontece primeiramente com os índices! Só multiplicar entre eles.

>💡 **Dica:** Usando a Propriedade 1, pode resolver isso de uma maneira mais fácil e rápido.

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F91f066e5-8e5a-4112-a98f-4d110fdcb1ae%2FUntitled.png?id=dd5d6316-837c-45af-b99d-1294c0c5b573&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1830&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

### Propriedade 6 - "Qual é o maior número?”

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F7467d71c-f522-4e75-b01b-e4b28c890b33%2FUntitled.png?id=3ff626a5-1ab3-424b-be22-dbb3b26041d9&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Isso é algo idêntico para quando quero facilitar alguma operação entre frações - multiplicando a fim de deixar com o mesmo denominador, por exemplo.

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F8a143533-e7ad-4e80-abf2-791deafd87ef%2FUntitled.png?id=255fe744-36be-4674-b7cd-b8ca836fa808&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1820&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Não tente adivinhar qual será o “número ideal” entre eles de cabeça - faça o MMC para descobrir.

Bom lembrar: quando forem números primos entre si, como foi o caso com o 3 e 4, basta apenas multiplicar entre eles. Afinal, não têm um divisor em comum entre eles, como é a definição propriamente dita.