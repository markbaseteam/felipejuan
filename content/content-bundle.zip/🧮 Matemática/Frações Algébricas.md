## Frações Algébricas

### Soma ou Subtração (Denominadores Diferentes)

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F7b5b672c-0ef1-4f10-8e4c-9eaf51a6b313%2FUntitled.png?id=ceeb2cf0-0f87-4da4-917f-91ae3c34597a&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Antes eu acreditava que, o ideal para fazer adição/subtração “diretamente” (sem MMC; multiplicando em cruz + apenas multiplicando os denominadores entre si), seria apenas para quando fossem números grandes e/ou mais de uma fração.

Porém esse pensamento está equivocado. O ideal para fazer isso é quando os denominadores são primos entre si.

Afinal, tendo nenhum divisor em comum, na prática, o que faz é multiplicar entre eles mesmo.

Paralalemente, em expressões algébricas, é algo idêntico quando os denominadores têm um fator em comum. Nesse caso, é essencial também realizar o mesmo processo, ou seja, fazer MMC entre eles, pegar o resultado, dividir pelo número de baixo, e o número obtido, multiplicar pelo de cima.