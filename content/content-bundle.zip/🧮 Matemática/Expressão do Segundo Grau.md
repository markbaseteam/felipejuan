## Expressão do Segundo Grau

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fe3279206-a649-499f-9df6-9bdb5c67c18d%2FUntitled.png?id=75ccac79-f669-4193-88ba-09a47c9d39de&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1200&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Sim, esse tópico será apenas essa imagem. Detalhe que nele, o Delta (△) já está substituído pela sua respectiva fórmula (b² - 4ac).

Apenas um lembrete que, depois de fazer as duas possibilidades - o resultado se o número for positivo, e outro, se for negativo - colocar eles em solução dessa forma:

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F94dd1866-c9aa-469b-86c0-9fbf6bdd26dd%2FUntitled.png?id=5e69ee1d-6861-4d1d-9a29-800950542cfe&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=350&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)