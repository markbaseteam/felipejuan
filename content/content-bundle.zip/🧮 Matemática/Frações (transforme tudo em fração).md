## Frações (transforme tudo em fração)

## Frações (transforme tudo em fração)
### Racionais + Irracionais = Reais

![|250](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F4a196f22-ef08-4c7c-b780-cdff22214feb%2FUntitled.png?id=838e79f1-9ff3-44c9-a6e7-6ce97a96761e&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1120&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

### Números Irracionais devem ser <mark style="background: #BBFABBA6;">aqueles com raízes que não dá para reolver, ou o próprio π.</mark>

![|250](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F850b0749-fd2d-4c40-a546-52379ff893ae%2FUntitled.png?id=4968c9ec-71d3-4888-987b-539e573042ad&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=850&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Isso também vale para quando eles estiverem em frações. Por exemplo, √2/3 também é irracional.

### Soma / Subtração de Frações
![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F7b945f5e-b47d-4ff5-a210-213217a1afe6%2FScreenshot_2023-05-28_103312_waifu2x_photo_scale.png?id=116a73ec-1afd-442b-b270-3669aae88106&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=770&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

A ideia de colocar esses azulzinhos multiplicando tal numerador/denominador de fração, é para indicar que multiplicando assim que dá o valor do MMC

Melhor começar a fazer MMC quando for **mais de 3 frações com denominadores diferentes.**

Faço o MMC entre os denominadores das frações. O resultado dela, será o dividendo de cada denominador. e o número obtido será pelo qual multiplicarei cada numerador…

Eu sei, eu sei… Em palavras, parece complicado mesmo, mas veja isso aqui:
![|450](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F7f7214f1-969f-467a-a021-e588f772f539%2F2023_05_28_11_01_Office_Lens.jpg?id=3a837e7b-30c4-495a-b879-91460c111d59&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

#### 📝 Anotações Pessoais
- O sinal de subtração SEMPRE tem que ficar no <mark style="background: #FFB86CA6;">meio da fração</mark> no **resultado final**
  ![|210](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F7e38686d-8056-4681-a8e1-8b80ea2e3799%2FUntitled.png?id=87fd01cb-47ff-4ee3-a51b-18c67bce4ef9&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=460&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

- Se for adição/subtração de três ou mais frações, ou o denominador/numerador for maior que 10, faça MMC.