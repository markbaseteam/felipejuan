## MMC & MDC
### MMC = Mínimo Múltiplo Comum

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fbe10a599-9c5a-49a6-a77f-1672cabebf23%2FUntitled.png?id=2560f606-3564-419f-87ce-136f34834705&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

### MDC = Máximo Divisor Comum

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F200edd4e-1c07-4376-94d5-2ee46151c623%2FUntitled.png?id=8c809a00-2e6d-4051-9ff2-b8fcfd986e68&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
- a \* b = c 
- a \* b = divisores de c
- c = múltiplo de a e b

### Detalhes
![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F75d0361e-31b0-4d26-b402-53b6af798ade%2FUntitled.png?id=4e0dde32-d3a9-49e1-a8ed-7166a6892a33&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
- - -
![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Ffc6b2489-6c6d-4c93-b658-bca665114cab%2FUntitled.png?id=feaf2cab-20bd-400b-8538-1118a3f6fa07&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)
- - -
![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F898eae49-8558-410e-a301-4289d3fb6a2f%2FUntitled.png?id=f6a4456f-5b81-45e2-9b12-560e1cb900e5&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Se precisar tornar algum número em notação científica, apenas precisa começar a contar a partir do segundo algarismo (ou começando no final e chegar até o primeiro; mesma coisa).

No caso de número decimal, para notação científica, a exponenciação será para contar até formar um número unitário.

Na exemplificação acima, foi 0,0038\. Veja que foi contada três, no total, que é o mesmo da potência ³.
