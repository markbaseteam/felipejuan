## Potenciação
**Propriedades para saber como simplificar:**

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F6ddd816f-7a64-4bf8-b2e3-d28923a06144%2FUntitled.png?id=cca847f5-5ff0-430a-acaf-5a93809a646e&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1870&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

[Pratiquei com os exercícios daqui.](https://site.colegiodominus.com.br/waUpload/1listapotencias00106022017075659.pdf)