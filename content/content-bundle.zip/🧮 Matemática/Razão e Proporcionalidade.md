## Razão e Proporcionalidade

![|200](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F62db5e8e-f31c-4cbc-bcad-f99bdc5803da%2FUntitled.png?id=20cbabea-9bef-4e0c-888e-3292455e120b&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=580&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Esse em branco, todo mundo deve saber - afinal, é a famosa “multiplicação em cruz”, ou também, se preferir, “multiplicar pela inversa da segunda fração”.

Porém essa segunda, é uma outra propriedade, menos conhecida, a qual dá a mesma coisa. Veja só uma aplicação dela:

![|300](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F737c542e-39a1-4d18-a7ee-1ec7b6a4e466%2FUntitled.png?id=2a4bdc52-8f60-4725-b833-034b04829a9a&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=580&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Números Diretamente Proporcionais

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F1f56e9a0-899c-4693-82c4-68991ca20d87%2FUntitled.png?id=c8131200-71f4-4d30-8a93-ae6e24170523&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Números Inversamente Proporcionais

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F2e62f6e8-e078-431f-8022-68e3ce9414bc%2FUntitled.png?id=5b04248c-1d3b-407d-b0a6-cb351a2b261f&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F7f5ff6c7-ee33-406a-b676-57039c38714b%2FUntitled.png?id=1c3231f8-d30f-4f2e-952e-1d1b4b9957c8&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=960&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F8acd577f-e2ff-49d1-a540-9e89c56afc2a%2FUntitled.png?id=29127cfc-213a-4ca3-819d-f02227dbfd30&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Apenas é relevante lembrar que, o motivo da fração estar “igual”; apenas multiplicando, após levar para o outro lado do = da conta, é porque ele estava dividindo o outro termo, afinal.

Já sabe, porém, jogando o número para o outro lado -

tá somando/subtraindo, passa a subtrair/somar

tá dividindo/multiplicando, passa a multiplicar/dividir

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fbf3cbdf0-fc8f-4557-8379-cf8359bb6623%2FUntitled.png?id=6d043229-3c57-44ea-9938-77e048739dca&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Existem várias formas diferentes para resolver essa questão. Ferreto, após descobrir o valor do A, poderia muito bem apenas substituir ela na segunda equação, a qual é apenas uma adição (logo, mais simples).

Porém, entendo que uma das intenções de aulas assim é para familiarizar com tal conteúdo, então faz sentido ter substituido na que leva a mais uma operações com razões, nesse caso.

Minha única dificuldade, que imagino, apenas com a prática de exercícios para se tornar automático a mim, foi de não ter primeira como isolaria uma das incógnitas na primeira equiação (P ficaria igual a 2A/9).

Além disso, me senti patético ter acertado, primeiramente, substituindo as respostas ![🤡](data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==). Fazia tempo que não fazia uma questão de Sistema de Equações e também não identifquei no momento.

Pelo menos, por conta da segunda, foi algo bem fácil, e relativamente rápido, para fazer, também. Todavia, não é recomendável, e agora que tenho uma ideia de como fazer, passarei a evitar.

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fe41fa900-c159-4010-bf85-ab18c9676491%2FUntitled.png?id=5f1edc02-9ad3-46a9-bbd6-6da920ea8508&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Essa não consegui resolver mesmo. Um dos vários hábitos em exatas que devo formar, é colocar e manter a letrinha em seus respectivos números \- é essencial, após montar a equação, para apenas ir cortando cada uma; mais simples de visualizar, ademais.

Fora isso, preciso começar a separar cada coisa que está pedindo no enunciado (sem isso, não terei como realizar análise dimensional). O mais importante, é saber exatamente o que deve ser a resposta, e separar ele.

Por exemplo, mesmo sabendo que a razão é o total de entrevistados sobre o número que responderam, não organizei isso em uma fração, para colocar apenas como igual a (estou escrevendo isso após a aula de Regra de Três Composta… 

Também estou percebendo como é algo que evitaria lá se tivesse prestado mais atenção aqui).

$$\frac{A = entrevistados}{T=responderam}$$

Sendo que o A, seria justamente a equação que vem a sua cabeça, conforme lê o enunciado de primeira, e o T, apenas a soma apenas dos dois números; nada de equações… não faria sentido isso.

Admito que ainda estou frustrado como essas coisas não vêm a minha cabeça; continuo tendo dificuldades para interpretar corretamente as questões de exatas

Isso foi apenas um dos grandes problemas - sinceramente, acertei nada nessa questão. Ao ler que o “a razão entre o número de mulheres e homens, nessa ordem, é igual a $\frac{1}{2}$, pensei da seguinte forma:

$$\frac{1}{2}=\frac{3H}{4}+\frac{2M}{3}$$

Ou seja, eu não tinha do que estava fazendo e nem do que deveria fazer. Em nenhum momento, pensei em fazer operações apenas com H e M, a qual é o pensamento correto para poder progredir.

Não necessariamente as contas - nesse caso, foi até desnecessário - mas assim, ter pensado “isso quer dizer, a cada 1 homem, tem duas mulheres” ou também “o número de mulheres é o dobro da quantidade de homens”. Ambos querem dizer que M = 2H.

Com isso, bastasse mais uma vez realizar o Sistema de Equações, com o Método de Substituição, para resolver. Afinal, o contrário, teríamos 2 incógnitas na equação, e com isso, teremos apenas um mesmo.

Pelo menos, consigo me ver não demorando/se atrapalhando mais para fazer esse tipo de conta. O hábito de cortar está crescendo e enxergar o que preciso fazer nessas contas “grandes”, “frações de frações”, não é mais uma grande dificuldade para mim.