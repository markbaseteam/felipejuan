## Fatoração - Produtos Notáveis
### Agrupamento
![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2Fdba1bfe6-8c20-46fa-aa09-d9d850c133e5%2FUntitled.png?id=001e2c07-1563-4e80-bdb8-c657de817f8e&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1800&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Bem, não tem tanta coisa de novo aqui - precisarei identificar o fator em comum e desfazer a distributiva. O que preciso identificar é quais serão, portanto.

### Produtos Notáveis

(a + b)² \- quadrado da soma de 2 termos

(a + b)² = a² + 2ab + b² Exemplo:

(x + 3)² = x² + 2(x)(3) + 3² (x + 3)² = x² + 6x + 9

(a - b)² \- quadrado da diferença de 2 termos

(a - b)² = a² - 2ab + b² Exemplo:

(x - 5)² = x² - 2 (x) (5) + 5² (x - 5)² \= x² - 10x + 25

(a + b)(a - b) \- quadrado da soma pela diferença de 2 termos

(a + b) (a - b) = a² - b² Exemplo:

x²−25x+5\=x²−5²x+5\=(x+5)(x−5)x+5\=x−5\\frac{x² -25}{x+5}=\\frac{x² -5²}{x+5}=\\frac{(x + 5)(x-5)}{x+5}=x-5

(a + b)³ \- cubo da soma de 2 termos

(a + b)³ = a³ + 3a²b + 3ab² + b³ Exemplo:

(x + 2)³ \= x³ + 3x²(2) + 3x(2²) + 2³ (x + 2)³ = x³ + 6x² + 12x + 8

(a + b)³ \- cubo da substração de 2 termos

(a - b)³ = a³ - 3a²b + 3ab² - b³ Exemplo:

(x - 2)³ \= x³ - 3x²(2) + 3x(2²) - 2³ (x - 2)³ = x³ - 6x² + 12x - 8

(a + b + c)² \- quadrado da soma de 3 termos

(a + b + c)² = a² + b² + c² + 2ab + 2ac + 2bc Exemplo:

(x+y+z)²\=x+y+z\\sqrt\[\]{(x+y+z)²}= x+y+z

