## Propriedade Distributiva
### Fator Comum

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F0aabf26b-68a5-4945-9ab0-5bc086117adc%2FUntitled.png?id=bb1d3fe0-8e77-454c-a1cc-1c8f716efd03&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1830&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Exemplo de como devo fazer o que tiver em comum, forem números, como os três últimos exercícios (mas em resumo, teria que usar MDC aqui):

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F56b3338b-64f1-4105-ac73-29c141a9b170%2F2023_05_31_10_31_Office_Lens.jpg?id=6a986f9b-c10b-45e1-adaf-45223136bbc3&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

### Apresentação da Fatoração

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F19dd5b9c-2872-43ba-a8bf-73ac5120eeb6%2FUntitled.png?id=b7187e4b-073e-4f37-a2a5-b05b9c8f8748&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Coloquei o print aqui, pois como está dizendo na imagem, pode acontecer das alternativas estar com uma resposta diferente - mas é o mesmo resultado, na verdade.

### 💡 Dica sobre o Sinal: (-1) \* (-1) = 1

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F2d74ddfb-f60e-4991-a2d3-cb1491bea4d9%2FUntitled.png?id=30d3fd49-c4ba-4dae-b60f-608d328911e9&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1940&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Mais uma vez, porque pode aparecer nas alternativas um pouco diferente - mas não esquecer que será a mesma expressão final. A justificativa do print é excelente. Tanto que coloquei no título do toggle.

Na dúvida, só fazer engenharia reversa para verificar.

## Propriedade Distributiva
### Fator Comum

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F0aabf26b-68a5-4945-9ab0-5bc086117adc%2FUntitled.png?id=bb1d3fe0-8e77-454c-a1cc-1c8f716efd03&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1830&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Exemplo de como devo fazer o que tiver em comum, forem números, como os três últimos exercícios (mas em resumo, teria que usar MDC aqui):

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F56b3338b-64f1-4105-ac73-29c141a9b170%2F2023_05_31_10_31_Office_Lens.jpg?id=6a986f9b-c10b-45e1-adaf-45223136bbc3&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

### Apresentação da Fatoração

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F19dd5b9c-2872-43ba-a8bf-73ac5120eeb6%2FUntitled.png?id=b7187e4b-073e-4f37-a2a5-b05b9c8f8748&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Coloquei o print aqui, pois como está dizendo na imagem, pode acontecer das alternativas estar com uma resposta diferente - mas é o mesmo resultado, na verdade.

### 💡 Dica sobre o Sinal: (-1) \* (-1) = 1

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F2d74ddfb-f60e-4991-a2d3-cb1491bea4d9%2FUntitled.png?id=30d3fd49-c4ba-4dae-b60f-608d328911e9&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1940&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Mais uma vez, porque pode aparecer nas alternativas um pouco diferente - mas não esquecer que será a mesma expressão final. A justificativa do print é excelente. Tanto que coloquei no título do toggle.

Na dúvida, só fazer engenharia reversa para verificar.

## Propriedade Distributiva
### Fator Comum

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F0aabf26b-68a5-4945-9ab0-5bc086117adc%2FUntitled.png?id=bb1d3fe0-8e77-454c-a1cc-1c8f716efd03&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1830&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Exemplo de como devo fazer o que tiver em comum, forem números, como os três últimos exercícios (mas em resumo, teria que usar MDC aqui):

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F56b3338b-64f1-4105-ac73-29c141a9b170%2F2023_05_31_10_31_Office_Lens.jpg?id=6a986f9b-c10b-45e1-adaf-45223136bbc3&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

### Apresentação da Fatoração

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F19dd5b9c-2872-43ba-a8bf-73ac5120eeb6%2FUntitled.png?id=b7187e4b-073e-4f37-a2a5-b05b9c8f8748&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=2000&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Coloquei o print aqui, pois como está dizendo na imagem, pode acontecer das alternativas estar com uma resposta diferente - mas é o mesmo resultado, na verdade.

### 💡 Dica sobre o Sinal: (-1) \* (-1) = 1

![](https://www.notion.so/image/https%3A%2F%2Fs3-us-west-2.amazonaws.com%2Fsecure.notion-static.com%2F2d74ddfb-f60e-4991-a2d3-cb1491bea4d9%2FUntitled.png?id=30d3fd49-c4ba-4dae-b60f-608d328911e9&table=block&spaceId=cfa1c0b0-6237-4d02-90e0-c01bae9aeb65&width=1940&userId=f76c6206-32cc-43fc-9931-6b22c28e4751&cache=v2)

Mais uma vez, porque pode aparecer nas alternativas um pouco diferente - mas não esquecer que será a mesma expressão final. A justificativa do print é excelente. Tanto que coloquei no título do toggle.

Na dúvida, só fazer engenharia reversa para verificar.